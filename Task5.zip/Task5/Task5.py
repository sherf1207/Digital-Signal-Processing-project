import numpy as np
import matplotlib.pyplot as plt
import tkinter as tk 
from tkinter import filedialog
import copy
import cmath
import math
from math import ceil
import os
import numpy as np
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import ttk ,Toplevel, Label, Button
from tkinter import messagebox , simpledialog, scrolledtext, filedialog, messagebox, Toplevel, ttk

from tkinter import filedialog
from scipy.signal import convolve

save_indeces=[]
save_samples=[]
save_samples_mult=[]
save_indeces_mult=[]
save_window_size=0
Task_name=""


# Global variables
file_path = ""
amplitude = None
min_val = None
max_val = None
levels = None
delta = None
quantized_values = None
quantization_labels = None
sampled_error = None
encoded_values=None




def ReadSignalFile(file_name):
    expected_indices=[]
    expected_samples=[]
    with open(file_name, 'r') as f:
        line = f.readline()
        line = f.readline()
        line = f.readline()
        line = f.readline()
        while line:
            L=line.strip()
            if len(L.split(' '))==2:
                L=line.split(' ')
                V1=int(L[0])
                V2=float(L[1])
                expected_indices.append(V1)
                expected_samples.append(V2)
                line = f.readline()
            else:
                break
    return expected_indices,expected_samples


# In[ ]:


def AddSignalSamplesAreEqual(userFirstSignal,userSecondSignal,Your_indices,Your_samples):
    if(userFirstSignal=='Signal1.txt' and userSecondSignal=='Signal2.txt'):
        file_name="" # write here path of signal1+signal2
    elif(userFirstSignal=='Signal1.txt' and userSecondSignal=='Signal3.txt'):
        file_name="" # write here path of signal1+signal3
    expected_indices,expected_samples=ReadSignalFile(file_name)          
    if (len(expected_samples)!=len(Your_samples)) and (len(expected_indices)!=len(Your_indices)):
        print("Addition Test case failed, your signal have different length from the expected one")
        return
    for i in range(len(Your_indices)):
        if(Your_indices[i]!=expected_indices[i]):
            print("Addition Test case failed, your signal have different indicies from the expected one") 
            return
    for i in range(len(expected_samples)):
        if abs(Your_samples[i] - expected_samples[i]) < 0.01:
            continue
        else:
            print("Addition Test case failed, your signal have different values from the expected one") 
            return
    print("Addition Test case passed successfully")





def MultiplySignalByConst(User_Const,Your_indices,Your_samples):

    if(User_Const==5):
        file_name="" # write here path of MultiplySignalByConstant-Signal1 - by 5.txt
    elif(User_Const==10):
        file_name="" # write here path of MultiplySignalByConstant-Signal2 - by 10.txt
        
    expected_indices,expected_samples=ReadSignalFile(file_name)      
    if (len(expected_samples)!=len(Your_samples)) and (len(expected_indices)!=len(Your_indices)):
        print("Multiply by "+User_Const.str()+ " Test case failed, your signal have different length from the expected one")
        return
    for i in range(len(Your_indices)):
        if(Your_indices[i]!=expected_indices[i]):
            print("Multiply by "+User_Const.str()+" Test case failed, your signal have different indicies from the expected one") 
            return
    for i in range(len(expected_samples)):
        if abs(Your_samples[i] - expected_samples[i]) < 0.01:
            continue
        else:
            print("Multiply by "+User_Const.str()+" Test case failed, your signal have different values from the expected one") 
            return
    print("Multiply by "+User_Const.str()+" Test case passed successfully")





#TaskName => choose it (string explain the name of task like (adding sig1+sig2,subtracting, .... etc.))
#output_file_name => output file path (output file given by TAs)
# Your_indices => your indices list from your code (generated/calculated by you)
# Your_samples => your samples list from your code (generated/calculated by you)
def SignalSamplesAreEqual(TaskName,output_file_name,Your_indices,Your_samples):
    global Task_name
    TaskName=Task_name
    expected_indices=[]
    expected_samples=[]
    with open(output_file_name, 'r') as f:
        line = f.readline()
        line = f.readline()
        line = f.readline()
        line = f.readline()
        while line:
            # process line
            L=line.strip()
            if len(L.split(' '))==2:
                L=line.split(' ')
                V1=int(L[0])
                V2=float(L[1])
                expected_indices.append(V1)
                expected_samples.append(V2)
                line = f.readline()
            else:
                break
    if (len(expected_samples)!=len(Your_samples)) and (len(expected_indices)!=len(Your_indices)):
         print(TaskName+" Test case failed, your signal have different length from the expected one")
         return
    for i in range(len(Your_indices)):
        if(Your_indices[i]!=expected_indices[i]):
            print(TaskName+" Test case failed, your signal have different indicies from the expected one") 
            return             
    for i in range(len(expected_samples)):
        if abs(Your_samples[i] - expected_samples[i]) < 0.01:
            continue
        else:
            print(TaskName+" Test case failed, your signal have different values from the expected one") 
            return
    print(TaskName+" Test case passed successfully")


def signal_continuous(indices, samples):
    
    plt.plot(indices, samples)
    plt.xlabel('Time (s)')
    plt.ylabel('Amplitude')
    plt.title('Continuous Signal')
    plt.show()

def signal_discrete(indices, samples):
    
    plt.stem(indices, samples)
    plt.xlabel('Sample Index (n)')
    plt.ylabel('Amplitude')
    plt.title('Discrete Signal')
    plt.show()

def load_data():
    file_path = filedialog.askopenfile()
    data = np.loadtxt(file_path, skiprows=3)
    if data.shape[1] >= 2:
        indices = data[:, 0]
        samples = data[:, 1]
        signal_continuous(indices, samples)
        signal_discrete(indices, samples)
    else:
        print("The file must have at least two columns.")

def task1():

    
    def signals(choice, amplitude, analog_frequence, sampling_frequence, phaseshift):
        t = np.arange(0, 1, 1 / sampling_frequence)
        if choice == 'sin':
            signal = amplitude * np.sin(2 * np.pi * analog_frequence * t + phaseshift)
        elif choice == 'cos':
            signal = amplitude * np.cos(2 * np.pi * analog_frequence * t + phaseshift)
        else:
            return None
        indices = np.arange(len(signal))
        return indices, signal


    def sine_wave():
        global save_indeces , save_samples
        amplitude = float(amplitudetextbox.get())
        analog_frequence = float(analogfrequencetextbox.get())
        sampling_frequence = float(samplingfrequencetextbox.get())
        phaseshift = float(phaseshifttextbox.get())

        indices, signal = signals('sin', amplitude, analog_frequence, sampling_frequence, phaseshift)
       
        save_indeces=indices
        save_samples=signal

        if indices is not None and signal is not None:
            signal_continuous(indices, signal)
            signal_discrete(indices, signal)      

       
    def cosine_wave():
        global  save_indeces , save_samples
        amplitude = float(amplitudetextbox.get())
        analog_frequence = float(analogfrequencetextbox.get())
        sampling_frequence = float(samplingfrequencetextbox.get())
        phaseshift = float(phaseshifttextbox.get())
        indices, signal = signals('cos', amplitude, analog_frequence, sampling_frequence, phaseshift)
        save_indeces=indices
        save_samples=signal

        if indices is not None and signal is not None:
            signal_continuous(indices, signal)
            signal_discrete(indices, signal)
    

    def compare_results():
      out_put=filedialog.askopenfilename(title="Select First Signal File", filetypes=[("Text Files", "*.txt")])
      SignalSamplesAreEqual(Task_name,out_put,save_indeces,save_samples)
    window = tk.Tk()
    window.title("Signal Generator")

    tk.Label(window, text="Enter amplitude", fg='black', font=('Arial', 15)).grid(row=0, column=0, padx=5, pady=10)
    amplitudetextbox = tk.Entry(window, fg='black', font=('Arial', 15))
    amplitudetextbox.grid(row=0, column=1)

    tk.Label(window, text="Enter analog frequency", fg='black', font=('Arial', 15)).grid(row=1, column=0, padx=5, pady=10)
    analogfrequencetextbox = tk.Entry(window, fg='black', font=('Arial', 15))
    analogfrequencetextbox.grid(row=1, column=1)

    tk.Label(window, text="Enter sampling frequency", fg='black', font=('Arial', 15)).grid(row=2, column=0, padx=5, pady=10)
    samplingfrequencetextbox = tk.Entry(window, fg='black', font=('Arial', 15))
    samplingfrequencetextbox.grid(row=2, column=1)

    tk.Label(window, text="Enter phase shift", fg='black', font=('Arial', 15)).grid(row=3, column=0, padx=5, pady=10)
    phaseshifttextbox = tk.Entry(window, fg='black', font=('Arial', 15))
    phaseshifttextbox.grid(row=3, column=1)

    sinbutton = tk.Button(window, command=sine_wave, text="Sine Wave", fg='black', font=('Arial', 15))
    sinbutton.grid(row=5, column=0, sticky=tk.W, padx=5, pady=10)

    cosbutton = tk.Button(window, command=cosine_wave, text="Cosine Wave", fg='black', font=('Arial', 15))
    cosbutton.grid(row=5, column=1, sticky=tk.W, padx=5, pady=10)

    loabutton = tk.Button(window, command=load_data, text="Read Data", fg='black', font=('Arial', 15))
    loabutton.grid(row=5, column=2, sticky=tk.W, padx=5, pady=10)

    compare_button = tk.Button(window, command=compare_results, text="Compare Results", fg='black', font=('Arial', 15))
    compare_button.grid(row=5, column=3, sticky=tk.W, padx=5, pady=10)

    signal_output_box = tk.Text(window, height=10, width=50, font=('Arial', 12))
    signal_output_box.grid(row=6, column=0, columnspan=2, padx=5, pady=10)

    window.mainloop()

def task2():
 child = Toplevel(root)
 child.title("Airthmatic Window")
 child.geometry("300x200")


 
 



 def browse_and_sum_signals():
    global save_samples,  Task_name
    Task_name="addition"
    file_path1 = filedialog.askopenfilename(title="Select First Signal File", filetypes=[("Text Files", "*.txt")])
    file_path2 = filedialog.askopenfilename(title="Select Second Signal File", filetypes=[("Text Files", "*.txt")])
    
    sampels1 = []
    sampels2 = []
    
    with open(file_path1, 'r') as f:
        for _ in range(3):
            f.readline()
        
        line = f.readline()
        while line:
            L = line.strip()
            if len(L.split(' ')) == 2:
                L = line.split(' ')
                V2 = float(L[1])
                sampels1.append(V2)
                line = f.readline()
            else:
                break

    with open(file_path2, 'r') as f:
        for _ in range(3):
            f.readline()
        
        line = f.readline()
        while line:
            L = line.strip()
            if len(L.split(' ')) == 2:
                L = line.split(' ')
                V2 = float(L[1])
                sampels2.append(V2)
                line = f.readline()
            else:
                break

    print("Samples from file 1:", sampels1)
    print("Samples from file 2:", sampels2)

    if len(sampels1) == len(sampels2) and len(sampels1) > 0:
        summed_samples = [a + b for a, b in zip(sampels1, sampels2)]
        save_samples = summed_samples
        print("Summed Samples:", save_samples)  
    else:
        print("Error: The two sample lists are of different lengths or empty.")

        print(len(save_samples),"in the function")

        plt.plot(summed_samples, label='Resulting Signal')
        plt.xlabel('Time')
        plt.ylabel('Amplitude')
        plt.legend()
        plt.show()

 def browse_and_subtract_signals():
    
    global save_samples,Task_name
    Task_name="subtraction"
    file_path2 = filedialog.askopenfilename(title="Select Second Signal File", filetypes=[("Text Files", "*.txt")])
    file_path1 = filedialog.askopenfilename(title="Select First Signal File", filetypes=[("Text Files", "*.txt")])

    samples1 = []
    samples2 = []


    with open(file_path1, 'r') as f:
        for _ in range(3): 
            f.readline()
        
        line = f.readline()
        while line:
            L = line.strip()
            if len(L.split(' ')) == 2:
                L = line.split(' ')
                V2 = float(L[1])
                samples1.append(V2)
                line = f.readline()
            else:
                break


    with open(file_path2, 'r') as f:
        for _ in range(3):  
            f.readline()
        
        line = f.readline()
        while line:
            L = line.strip()
            if len(L.split(' ')) == 2:
                L = line.split(' ')
                V2 = float(L[1])
                samples2.append(V2)
                line = f.readline()
            else:
                break

    print("Samples from file 1:", samples1)
    print("Samples from file 2:", samples2)

    if len(samples1) == len(samples2) and len(samples1) > 0:
        subtracted_samples = [a - b for a, b in zip(samples1, samples2)]
        save_samples = subtracted_samples
        print("Subtracted Samples:", save_samples)  

        plt.plot(subtracted_samples, label='Resulting Signal (File1 - File2)')
        plt.xlabel('Time')
        plt.ylabel('Amplitude')
        plt.legend()
        plt.show()
    else:
        print("Error: The two sample lists are of different lengths or empty.")

 def browse_and_multiply_signal():
    global   save_samples,Task_name
    Task_name="multibplication"
    
    file_paths = filedialog.askopenfilenames(title="Select Signal Files", filetypes=[("Text Files", "*.txt")])
    
    constant = simpledialog.askinteger("Input", "Enter a constant value to multiply the signal (e.g., 2 for amplification, -1 for inversion):")
    
    if constant is None:  
        return
    
    signals = []
    for path in file_paths:
        with open(path, 'r') as f:
            signal = np.array([float(line.split()[1]) for line in f.readlines()[3:]])  # Skip first 3 lines (header)
            signals.append(signal)

    amplified_signals = np.array(signals[0]) * constant


    save_samples=amplified_signals

    print(len(save_samples))
    print(save_samples.shape)
    print(save_samples)

    plt.plot(amplified_signals[0], label='Amplified Signal')
    plt.xlabel('Time')
    plt.ylabel('Amplitude')
    plt.legend()
    plt.title(f'Signal Multiplied by {constant}')
    plt.show()
 def browse_and_square_signal():
    global save_samples,Task_name
    Task_name="square signal"


    file_path = filedialog.askopenfilename(title="Select Signal File", filetypes=[("Text Files", "*.txt")])


    signal = []


    with open(file_path, 'r') as f:
        for _ in range(3): 
            f.readline()

        for line in f:  
            parts = line.strip().split()
            if len(parts) == 2:
                value = float(parts[1])
                signal.append(value)


    signal = np.array(signal)

    squared_signal = np.square(signal)

    save_samples = squared_signal

    print("Squared Signal:", squared_signal)



    
    plt.plot(squared_signal[0], label='Squared Signal')
    plt.xlabel('Time')
    plt.ylabel('Amplitude')
    plt.legend()
    plt.title('Signal Squared')
    plt.show()
 def browse_and_normalize_signal():
    global save_samples ,Task_name
    Task_name="normalize signal"

    choice = simpledialog.askstring("Input", 
                                    "Choose normalization range:\n'1' for [-1, 1]\n'2' for [0, 1]")

    if choice not in ['1', '2']:
        print("Invalid choice. Please select '1' or '2'.")
        return

    file_paths = filedialog.askopenfilenames(
        title="Select Signal Files", 
        filetypes=[("Text Files", "*.txt")]
    )
    
    signals = []  

    for path in file_paths:
        with open(path, 'r') as f:
            signal = np.array([float(line.split()[1]) for line in f.readlines()[3:]])
            signals.append(signal)

    signal = signals[0]  
    if choice == '1': 
        norm_signal = 2 * (signal - np.min(signal)) / (np.max(signal) - np.min(signal)) - 1
    else: 
        norm_signal = (signal - np.min(signal)) / (np.max(signal) - np.min(signal))

    save_samples = norm_signal
    plt.plot(norm_signal, label='Normalized Signal')
    plt.xlabel('Time')
    plt.ylabel('Amplitude')
    plt.legend()
    plt.title(f'Signal Normalized to { "[-1, 1]" if choice == "1" else "[0, 1]"}')
    plt.show()
 
 def accumulate_signal():
    global save_samples ,Task_name
    Task_name="accumulate signal"

    file_path = filedialog.askopenfilename(title="Select Signal File", filetypes=[("Text Files", "*.txt")])

    accumulated_signal = [0]  

    with open(file_path, 'r') as f:
        for _ in range(3):
            f.readline()

        for line in f:
            parts = line.strip().split()
            if len(parts) == 2:
                value = int(parts[1])  
                accumulated_signal.append(accumulated_signal[-1] + value)
        accumulated_signal = accumulated_signal[1:]
        save_samples=accumulated_signal


        plt.plot(accumulated_signal, label=f'Accumulated Signal ')

        plt.xlabel('Time')
        plt.ylabel('Amplitude')
        plt.legend()
        plt.title('Accumulated Signal(s) (Cumulative Sum)')
        plt.show()
 def compare_results():
      Outpot_file_path = filedialog.askopenfilename()

      SignalSamplesAreEqual(Task_name,Outpot_file_path,save_indeces_mult,save_samples)

 Button(child, text="Add waves", command=browse_and_sum_signals, font=('Arial', 12)).pack(pady=20)
 Button(child, text="Sub waves", command=browse_and_subtract_signals, font=('Arial', 12)).pack(pady=20)
 Button(child, text="Scale Wave", command=browse_and_multiply_signal, font=('Arial', 12)).pack(pady=20)
 Button(child, text="Square Wave", command=browse_and_square_signal, font=('Arial', 12)).pack(pady=20)
 Button(child, text="Normalize Wave", command=browse_and_normalize_signal, font=('Arial', 12)).pack(pady=20)
 Button(child, text="Accumulate Wave", command=accumulate_signal, font=('Arial', 12)).pack(pady=20)
 Button(child, text="Compare", command=compare_results, font=('Arial', 12)).pack(pady=20)

def task3():
    global file_path, amplitude, min_val, max_val, levels, delta, quantized_values, quantization_labels, sampled_error,encoded_values



    def load_data():
        """Load data from a file."""
        global file_path, amplitude, min_val, max_val
        file_path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if file_path:
            file_label.config(text=file_path)
            try:
                data = np.loadtxt(file_path, skiprows=3)
                amplitude = data[:, 1]  # Amplitude column
                min_val, max_val = np.min(amplitude), np.max(amplitude)
                messagebox.showinfo("Success", "Data loaded successfully.")
            except Exception as e:
                messagebox.showerror("Error", f"Error loading data: {e}")


    def update_input_label():
        """Update the input label based on the selected choice."""
        if choice_var.get() == "bits":
            input_label.config(text="Enter Number of Bits:")
        else:
            input_label.config(text="Enter Number of Levels:")


    def perform_quantization():
        """Perform the quantization based on user input."""
        global levels, delta, quantized_values, quantization_labels, sampled_error
        if amplitude is None:
            messagebox.showwarning("Warning", "Please load the data file first.")
            return

        try:
            user_input = int(input_entry.get())
            if choice_var.get() == "bits":
                levels = 2 ** user_input
                bits = user_input
            else:
                levels = user_input
                bits = int(np.log2(levels))  # Calculate bits based on levels

            delta = (max_val - min_val) / levels

            # Create quantization ranges and midpoints
            ranges = [(min_val + i * delta, min_val + (i + 1) * delta) for i in range(levels)]
            midpoints = [(start + end) / 2 for start, end in ranges]

            quantized_values = np.zeros_like(amplitude)
            quantization_labels = []  # Store the encoded levels (labels)
            sampled_error = []  # Store the quantization errors

            for i, value in enumerate(amplitude):
                for j, (start, end) in enumerate(ranges):
                    if start <= value < end:
                        quantized_values[i] = midpoints[j]
                        # Calculate the quantization error
                        error = quantized_values[i] - amplitude[i]
                        sampled_error.append(error)  # Store error
                        # Format the label to have leading zeros
                        binary_representation = format(j, f'0{bits}b')  # Use bits for formatting
                        quantization_labels.append(binary_representation)  # Store label as binary string
                        break
                else:
                    if value == max_val:
                        quantized_values[i] = midpoints[-1]
                        error = quantized_values[i] - amplitude[i]
                        sampled_error.append(error)  # Store error
                        binary_representation = format(levels - 1, f'0{bits}b')  # Format the label for max value
                        quantization_labels.append(binary_representation)

            # Display quantized values and errors
            result = ""
            for quant, label, error in zip(quantized_values, quantization_labels, sampled_error):
                result += f"Quantized Value: {quant:.4f}  Bit: {label}  Error: {error:.4f}\n"

            result_label.config(text=result)
            messagebox.showinfo("Quantization Complete", "Quantization completed successfully.")

        except ValueError:
            messagebox.showerror("Error", "Please enter a valid number for bits or levels.")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred during quantization: {e}")


    def read_test_output(file_name):
        """Read the expected output from the test file."""
        expected_indices = []
        expected_encoded_values = []
        expected_quantized_values = []
        expected_errors = []

        with open(file_name, 'r') as f:
            for line in f:
                if line.strip():  # Check for non-empty line
                    parts = line.split()
                    if len(parts) == 4:  # Expecting 4 values in the output
                        expected_indices.append(int(parts[0]))
                        expected_encoded_values.append(parts[1])
                        expected_quantized_values.append(float(parts[2]))
                        expected_errors.append(float(parts[3]))

        return expected_indices, expected_encoded_values, expected_quantized_values, expected_errors


    def compare_quantization():
        """Compare the quantized values using QuantizationTest1."""
        if not file_path:
            messagebox.showwarning("Warning", "Please load the data file first.")
            return
        if quantized_values is None or quantization_labels is None:
            messagebox.showwarning("Warning", "Please perform quantization first.")
            return

        test_file = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if test_file:
            expected_indices, expected_encoded_values, expected_quantized_values, expected_errors = read_test_output(
                test_file)
            if len(expected_encoded_values) != len(quantization_labels):
                print("QuantizationTest1 Test case failed, your signal has different lengths from the expected one")
                return

            for i in range(len(quantization_labels)):
                if quantization_labels[i] != expected_encoded_values[i]:
                    print(
                        f"QuantizationTest1 Test case failed at index {i}, your EncodedValue: {quantization_labels[i]}, Expected: {expected_encoded_values[i]}")
                    return

                if abs(quantized_values[i] - expected_quantized_values[i]) >= 0.01:
                    print(
                        f"QuantizationTest1 Test case failed at index {i}, your QuantizedValue: {quantized_values[i]}, Expected: {expected_quantized_values[i]}")
                    return

            print("QuantizationTest1 Test case passed successfully")


    def compare_quantization_levels():
        """Compare the quantized values using QuantizationTest2."""
        if not file_path:
            messagebox.showwarning("Warning", "Please load the data file first.")
            return
        if quantized_values is None or quantization_labels is None or sampled_error is None:
            messagebox.showwarning("Warning", "Please perform quantization first.")
            return

        test_file = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if test_file:
            expected_indices, expected_encoded_values, expected_quantized_values, expected_errors = read_test_output(
                test_file)

            # Generate expected interval indices (0-based for comparison)
            interval_indices = list(range(len(quantization_labels)))
            if len(expected_encoded_values) != len(quantization_labels) or len(expected_quantized_values) != len(
                    quantized_values) or len(expected_errors) != len(sampled_error):
                print("QuantizationTest2 Test case failed, your signal has different lengths from the expected one")
                return

            for i in range(len(quantization_labels)):
                if quantization_labels[i] != expected_encoded_values[i]:
                    print(
                        f"QuantizationTest2 Test case failed at index {i}, your EncodedValue: {quantization_labels[i]}, Expected: {expected_encoded_values[i]}")
                    return

                if abs(quantized_values[i] - expected_quantized_values[i]) >= 0.01:
                    print(
                        f"QuantizationTest2 Test case failed at index {i}, your QuantizedValue: {quantized_values[i]}, Expected: {expected_quantized_values[i]}")
                    return

                if abs(sampled_error[i] - expected_errors[i]) >= 0.01:
                    print(
                        f"QuantizationTest2 Test case failed at index {i}, your Error: {sampled_error[i]}, Expected: {expected_errors[i]}")
                    return

            print("QuantizationTest2 Test case passed successfully")

    def QuantizationTest1(file_name,Your_EncodedValues,Your_QuantizedValues):
     
     expectedEncodedValues=[]
     expectedQuantizedValues=[]
     with open(file_name, 'r') as f:
        line = f.readline()
        line = f.readline()
        line = f.readline()
        line = f.readline()
        while line:
            # process line
            L=line.strip()
            if len(L.split(' '))==2:
                L=line.split(' ')
                V2=str(L[0])
                V3=float(L[1])
                expectedEncodedValues.append(V2)
                expectedQuantizedValues.append(V3)
                line = f.readline()
            else:
                break
     if( (len(Your_EncodedValues)!=len(expectedEncodedValues)) or (len(Your_QuantizedValues)!=len(expectedQuantizedValues))):
        print("QuantizationTest1 Test case failed, your signal have different length from the expected one")
        return
     for i in range(len(Your_EncodedValues)):
        if(Your_EncodedValues[i]!=expectedEncodedValues[i]):
            print("QuantizationTest1 Test case failed, your EncodedValues have different EncodedValues from the expected one") 
            return
     for i in range(len(expectedQuantizedValues)):
        if abs(Your_QuantizedValues[i] - expectedQuantizedValues[i]) < 0.01:
            continue
        else:
            print("QuantizationTest1 Test case failed, your QuantizedValues have different values from the expected one") 
            return
     print("QuantizationTest1 Test case passed successfully")
    def QuantizationTest2(file_name,Your_IntervalIndices,Your_EncodedValues,Your_QuantizedValues,Your_SampledError):
        expectedIntervalIndices=[]
        expectedEncodedValues=[]
        expectedQuantizedValues=[]
        expectedSampledError=[]
        with open(file_name, 'r') as f:
            line = f.readline()
            line = f.readline()
            line = f.readline()
            line = f.readline()
            while line:
                # process line
                L=line.strip()
                if len(L.split(' '))==4:
                    L=line.split(' ')
                    V1=int(L[0])
                    V2=str(L[1])
                    V3=float(L[2])
                    V4=float(L[3])
                    expectedIntervalIndices.append(V1)
                    expectedEncodedValues.append(V2)
                    expectedQuantizedValues.append(V3)
                    expectedSampledError.append(V4)
                    line = f.readline()
                else:
                    break
        if(len(Your_IntervalIndices)!=len(expectedIntervalIndices)
        or len(Your_EncodedValues)!=len(expectedEncodedValues)
        or len(Your_QuantizedValues)!=len(expectedQuantizedValues)
        or len(Your_SampledError)!=len(expectedSampledError)):
            print("QuantizationTest2 Test case failed, your signal have different length from the expected one")
            return
        for i in range(len(Your_IntervalIndices)):
            if(Your_IntervalIndices[i]!=expectedIntervalIndices[i]):
                print("QuantizationTest2 Test case failed, your signal have different indicies from the expected one") 
                return
        for i in range(len(Your_EncodedValues)):
            if(Your_EncodedValues[i]!=expectedEncodedValues[i]):
                print("QuantizationTest2 Test case failed, your EncodedValues have different EncodedValues from the expected one") 
                return
            
        for i in range(len(expectedQuantizedValues)):
            if abs(Your_QuantizedValues[i] - expectedQuantizedValues[i]) < 0.01:
                continue
            else:
                print("QuantizationTest2 Test case failed, your QuantizedValues have different values from the expected one") 
                return
        for i in range(len(expectedSampledError)):
            if abs(Your_SampledError[i] - expectedSampledError[i]) < 0.01:
                continue
            else:
                print("QuantizationTest2 Test case failed, your SampledError have different values from the expected one") 
                return
        print("QuantizationTest2 Test case passed successfully")

    def QuantizationTest():
        file_name2=filedialog.askopenfilename(title="Select First Signal File", filetypes=[("Text Files", "*.txt")])
        Your_EncodedValues5=quantization_labels
        Your_QuantizedValues=quantized_values
        QuantizationTest1(file_name2,Your_EncodedValues5,Your_QuantizedValues)

    root = tk.Tk()
    root.title("Quantization Tool")

    frame = tk.Frame(root)
    frame.pack(pady=10)

    file_label = tk.Label(frame, text="No file loaded")
    file_label.pack()

    load_button = tk.Button(frame, text="Load Data", command=load_data)
    load_button.pack(pady=5)

    choice_var = tk.StringVar(value="bits")

    tk.Radiobutton(frame, text="Number of Levels", variable=choice_var,
                value="levels", command=update_input_label).pack(anchor="w")
    tk.Radiobutton(frame, text="Number of Bits", variable=choice_var,
                value="bits", command=update_input_label).pack(anchor="w")

    input_label = tk.Label(frame, text="Enter Number of Levels:")
    input_label.pack()

    input_entry = tk.Entry(frame)
    input_entry.pack()

    quantize_button = tk.Button(frame, text="Quantize", command=perform_quantization)
    quantize_button.pack(pady=5)

    compare_button = tk.Button(frame, text="Compare Quantization (Test 1)", command=QuantizationTest)
    compare_button.pack(pady=5)

    compare_levels_button = tk.Button(frame, text="Compare Quantization (Test 2)", command=compare_quantization_levels)
    compare_levels_button.pack(pady=5)

    result_label = tk.Label(frame, text="", justify=tk.LEFT)
    result_label.pack(pady=10)

    root.mainloop()

def task4():

    global last_dft_output, last_idft_output
    last_dft_output = None
    last_idft_output = None

    # -------------------- Helpers --------------------
    def RoundPhaseShift(P):
        while P < 0:
            P += 2 * math.pi
        return float(P % (2 * math.pi))

    def SignalComapreAmplitude(a, b, tol=1e-3):
        return np.allclose(a, b, atol=tol, rtol=0)

    def SignalComaprePhaseShift(a, b, tol=1e-3):
        return np.allclose(np.mod(a, 2*np.pi), np.mod(b, 2*np.pi), atol=tol, rtol=0)

    # -------------------- File Reader --------------------
    def read_signal_from_file2():
        filename = filedialog.askopenfilename(title="Select a Signal File")
        if not filename:
            return None, None

        with open(filename, 'r') as file:
            lines = [line.strip() for line in file if line.strip()]

        # try to detect an explicit header type if present in either first or second line
        header_type = None
        for idx in (0, 1):
            if idx < len(lines):
                s = lines[idx].strip()
                if s in ('0', '1'):
                    try:
                        header_type = int(s)
                        break
                    except ValueError:
                        header_type = None

        # pick a likely data-start index (most files you've shown use 3, but be forgiving)
        # we'll examine from line index 2 onward if available, otherwise from 0
        start_idx = 3 if len(lines) > 3 else 2 if len(lines) > 2 else 0
        data_lines = lines[start_idx:]

        # helpers to try parsing as time-domain (single value per line) or freq-domain (two values per line)
        def try_parse_time(lines_):
            samples = []
            for line in lines_:
                parts = line.split()
                # allow lines like "index value" => take the second token,
                # or allow single-token lines as direct samples
                if len(parts) == 1:
                    token = parts[0]
                elif len(parts) >= 2:
                    token = parts[1]
                else:
                    return None
                try:
                    samples.append(float(str(token).rstrip('f')))
                except ValueError:
                    return None
            return np.array(samples, dtype=float) if samples else None

        def try_parse_freq(lines_):
            data = []
            for line in lines_:
                parts = line.split()
                # we expect (amp phase) pairs; allow trailing 'f' on numbers
                if len(parts) < 2:
                    return None
                try:
                    amp = float(str(parts[0]).rstrip('f'))
                    ph = float(str(parts[1]).rstrip('f'))
                    data.append([amp, ph])
                except ValueError:
                    return None
            return np.array(data, dtype=float) if data else None

        # attempt both parsings
        parsed_time = try_parse_time(data_lines)
        parsed_freq = try_parse_freq(data_lines)

        # decide which to return
        if parsed_freq is not None and parsed_time is None:
            return parsed_freq, "freq"
        if parsed_time is not None and parsed_freq is None:
            return parsed_time, "time"

        # ambiguous: both parsed successfully (rare). Prefer header_type if available.
        if header_type is not None:
            if header_type == 0 and parsed_time is not None:
                return parsed_time, "time"
            if header_type == 1 and parsed_freq is not None:
                return parsed_freq, "freq"

        # fallback: if first data line has 2 tokens, prefer freq
        if data_lines:
            if len(data_lines[0].split()) >= 2 and parsed_freq is not None:
                return parsed_freq, "freq"
            if len(data_lines[0].split()) == 1 and parsed_time is not None:
                return parsed_time, "time"

        # last resort: if nothing parsed, try using original behavior reading lines[1]
        try:
            signal_type = int(lines[1].strip())
        except Exception:
            return None, None

        if signal_type == 0:
            return parsed_time, "time" if parsed_time is not None else (None, None)
        elif signal_type == 1:
            return parsed_freq, "freq" if parsed_freq is not None else (None, None)
        return None, None


    # -------------------- DFT --------------------
    def dft(signal, fs):
        N = len(signal)
        output = np.zeros((N, 2))

        for k in range(N):
            Xk = sum(signal[n] * np.exp(-2j * np.pi * k * n / N) for n in range(N))
            amp = abs(Xk)
            ph = RoundPhaseShift(np.angle(Xk))
            output[k] = [amp, ph]

        print("\n=== DFT OUTPUT (Amplitude | Phase) ===")
        for row in output:
            print(f"{row[0]:.6f}\t{row[1]:.6f}")
        print("=====================================\n")

        # Optional: plot
        plt.figure(figsize=(8, 4))
        plt.stem(range(N), output[:, 0], basefmt="", label="Amplitude")
        plt.xlabel("Index")
        plt.ylabel("Amplitude")
        plt.legend()
        plt.show()

        plt.figure(figsize=(8, 4))
        plt.stem(range(N), output[:, 1], basefmt="", label="Phase")
        plt.xlabel("Index")
        plt.ylabel("Phase")
        plt.legend()
        plt.show()

        return output

    # -------------------- IDFT --------------------
    def idft(freq_data):

        N = len(freq_data)
        signal = np.zeros(N, dtype=complex)

        for n in range(N):
            Xn = 0
            for k in range(N):
                amp = freq_data[k, 0]
                ph = freq_data[k, 1]
                Xk = amp * np.exp(1j * ph)
                Xn += Xk * np.exp(2j * np.pi * k * n / N)
            signal[n] = Xn / N

        # Convert reconstructed complex signal to amplitude/phase
        amplitude = np.abs(signal)
        phase = np.angle(signal)
        phase = [RoundPhaseShift(p) for p in phase]

        indices = np.arange(N)
        output = np.column_stack((indices, amplitude))

        print("\n=== IDFT OUTPUT (Index | Amplitude | Phase) ===")
        for row in output:
            print(f"{int(row[0])}\t{row[1]:.6f}")
        print("==============================================\n")

        plt.figure(figsize=(8, 4))
        plt.plot(np.real(signal))
        plt.title("Reconstructed Signal (IDFT)")
        plt.xlabel("Sample")
        plt.ylabel("Amplitude")
        plt.grid(True)
        plt.show()

        return output


    # -------------------- Actions --------------------
    def dft_action(freq):
        global last_dft_output
        signal, t = read_signal_from_file2()
        if signal is None or t != "time":
            messagebox.showerror("Error", "Please select a valid time-domain signal file.")
            return
        last_dft_output = dft(signal, float(freq))

    def idft_action():
        global last_idft_output
        freq_data, t = read_signal_from_file2()
        if freq_data is None or t != "freq":
            messagebox.showerror("Error", "Please select a valid frequency-domain signal file.")
            return
        last_idft_output = idft(freq_data)

    def compare_button_action():
        global last_dft_output, last_idft_output
        if last_dft_output is None and last_idft_output is None:
            messagebox.showwarning("No Output", "Please run DFT or IDFT first.")
            return

        filename = filedialog.askopenfilename(title="Select Output File to Compare With")
        if not filename:
            return

        # Read comparison file
        with open(filename, 'r') as f:
            lines = [line.strip() for line in f if line.strip()]

        data = []
        for line in lines[3:]:
            parts = line.split()
            if len(parts) == 2:
                try:
                    data.append([float(parts[0].rstrip('f')), float(parts[1].rstrip('f'))])
                except ValueError:
                    continue
        data = np.array(data)

        # Decide comparison target
        if last_idft_output is not None:
            output = last_idft_output
            result_type = "IDFT"
        else:
            output = last_dft_output
            result_type = "DFT"

        amp_match = SignalComapreAmplitude(output[:, 0], data[:, 0])
        phase_match = SignalComaprePhaseShift(output[:, 1], data[:, 1])

        if amp_match and phase_match:
            messagebox.showinfo("Comparison", f"{result_type} output matches file ✅")
        else:
            messagebox.showerror("Comparison", f"{result_type} output does NOT match file ❌")

    child = Toplevel(root)
    child.title("Fourier Transform")
    child.geometry("360x250")

    ttk.Label(child, text="Enter sampling frequency:", font=("Helvetica", 10)).grid(row=1, column=0, padx=5, pady=10)
    sampling_freq_entry = ttk.Entry(child)
    sampling_freq_entry.grid(row=1, column=1)

    ttk.Button(child, text="Compute DFT", command=lambda: dft_action(sampling_freq_entry.get()), width=30).grid(row=2, column=0, columnspan=2, pady=5)
    ttk.Button(child, text="Compute IDFT", command=idft_action, width=30).grid(row=3, column=0, columnspan=2, pady=5)
    ttk.Button(child, text="Compare Output", command=compare_button_action, width=30).grid(row=4, column=0, columnspan=2, pady=5)
    root.mainloop()

def task5():

    window = Toplevel()
    window.title("FFT / IFFT Tool")
    window.geometry("350x300")

    FFT_mode = None
    fft_result = None
    signal_values = []
    freq_polar = None

    def read_signal_from_file2():
        filename = filedialog.askopenfilename(title="Select a Signal File")
        if not filename:
            return None, None

        with open(filename, 'r') as file:
            lines = [line.strip() for line in file if line.strip()]

        header_type = None
        for idx in (0, 1):
            if idx < len(lines):
                s = lines[idx].strip()
                if s in ('0', '1'):
                    try:
                        header_type = int(s)
                        break
                    except ValueError:
                        header_type = None

        start_idx = 3 if len(lines) > 3 else 2 if len(lines) > 2 else 0
        data_lines = lines[start_idx:]

        def try_parse_time(lines_):
            samples = []
            for line in lines_:
                parts = line.split()
                if len(parts) == 1:
                    token = parts[0]
                elif len(parts) >= 2:
                    token = parts[1]
                else:
                    return None
                try:
                    samples.append(float(str(token).rstrip('f')))
                except ValueError:
                    return None
            return np.array(samples, dtype=float) if samples else None

        def try_parse_freq(lines_):
            data = []
            for line in lines_:
                parts = line.split()
                if len(parts) < 2:
                    return None
                try:
                    amp = float(str(parts[0]).rstrip('f'))
                    ph = float(str(parts[1]).rstrip('f'))
                    data.append([amp, ph])
                except ValueError:
                    return None
            return np.array(data, dtype=float) if data else None

        parsed_time = try_parse_time(data_lines)
        parsed_freq = try_parse_freq(data_lines)

        if parsed_freq is not None and parsed_time is None:
            return parsed_freq, "freq"
        if parsed_time is not None and parsed_freq is None:
            return parsed_time, "time"

        if header_type is not None:
            if header_type == 0 and parsed_time is not None:
                return parsed_time, "time"
            if header_type == 1 and parsed_freq is not None:
                return parsed_freq, "freq"

        if data_lines:
            if len(data_lines[0].split()) >= 2 and parsed_freq is not None:
                return parsed_freq, "freq"
            if len(data_lines[0].split()) == 1 and parsed_time is not None:
                return parsed_time, "time"

        try:
            signal_type = int(lines[1].strip())
        except:
            return None, None

        if signal_type == 0:
            return parsed_time, "time"
        elif signal_type == 1:
            return parsed_freq, "freq"

        return None, None

    def load_time_domain_signal():
        nonlocal signal_values, FFT_mode, fft_result

        data, t = read_signal_from_file2()
        if t != "time":
            print("This file is NOT a time-domain signal.")
            return

        signal_values = data
        FFT_mode = 1
        fft_result = None
        print("Loaded time-domain signal — ready for FFT")


    def load_frequency_polar():
        nonlocal freq_polar, FFT_mode, fft_result

        data, t = read_signal_from_file2()
        if t != "freq":
            print("This file is NOT polar frequency components.")
            return

        freq_polar = data
        FFT_mode = 2
        fft_result = data[:,0] * np.exp(1j * data[:,1])

        print("Loaded polar frequency components — ready for IFFT")


    def apply_fft():
        nonlocal fft_result

        if FFT_mode != 1:
            print("Load a TIME-DOMAIN signal first.")
            return

        if len(signal_values) == 0:
            print("No time-domain signal loaded.")
            return

        fs = simpledialog.askfloat(
            "Sampling Frequency",
            "Enter sampling frequency (Hz):",
            parent=window
        )
        if fs is None:
            return

        N = len(signal_values)
        fft_result = np.fft.fft(signal_values)
        freq = np.fft.fftfreq(N, d=1/fs)

        # Magnitude
        plt.figure()
        plt.plot(freq, np.abs(fft_result))
        plt.title("FFT Magnitude Spectrum")
        plt.xlabel("Frequency (Hz)")
        plt.ylabel("Magnitude")
        plt.grid()

        # Phase
        plt.figure()
        plt.plot(freq, np.angle(fft_result))
        plt.title("FFT Phase Spectrum")
        plt.xlabel("Frequency (Hz)")
        plt.ylabel("Phase")
        plt.grid()

        plt.show()

    def apply_ifft():
        if FFT_mode != 2:
            print("Load POLAR frequency components first.")
            return

        reconstructed = np.fft.ifft(fft_result).real

        plt.figure()
        plt.stem(reconstructed)
        plt.title("Reconstructed Signal (IFFT)")
        plt.xlabel("n")
        plt.ylabel("Amplitude")
        plt.grid()
        plt.show()

    Button(window, text="1) Load Time-Domain Signal (FFT)", width=32, command=load_time_domain_signal).pack(pady=5)
    Button(window, text="2) Load Polar Frequency Components (IFFT)", width=32, command=load_frequency_polar).pack(pady=5)

    Button(window, text="Perform FFT", width=22, command=apply_fft).pack(pady=10)
    Button(window, text="Perform IFFT", width=22, command=apply_ifft).pack(pady=5)



root = tk.Tk()

sinbutton = tk.Button(root, command=task1, text="Signal Generator", fg='black', font=('Arial', 15))
sinbutton.grid(row=5, column=1, sticky=tk.W, padx=5, pady=10)

AIrthmaticbutton = tk.Button(root, command=task4, text="Fourier transform", fg='orange', font=('Arial', 15))
AIrthmaticbutton.grid(row=5, column=7, sticky=tk.W, padx=5, pady=10)

AIrthmaticbutton = tk.Button(root, command=task2, text="Airathmatic Operations", fg='red', font=('Arial', 15))
AIrthmaticbutton.grid(row=5, column=3, sticky=tk.W, padx=5, pady=10)


AIrthmaticbutton = tk.Button(root, command=task3, text="Quantization", fg='brown', font=('Arial', 15))
AIrthmaticbutton.grid(row=5, column=5, sticky=tk.W, padx=5, pady=10)

AIrthmaticbutton = tk.Button(root, command=task5, text="FFT & IFFT", fg='blue', font=('Arial', 15))
AIrthmaticbutton.grid(row=5, column=9, sticky=tk.W, padx=5, pady=10)

root.mainloop()

